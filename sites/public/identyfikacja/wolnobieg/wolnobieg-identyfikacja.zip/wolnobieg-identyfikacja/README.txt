Wolnobieg: identyfikacja wizualna

Projekt przykładowy. Wolnobieg to zmyślona firma. Projekt i wykonanie: Adrian Turbiński.

Zawartość paczki:
  Logo: 30 plików (PDF, PNG, SVG)
  Ikona strony: 3 pliki (PNG, ICO, SVG)
  Kolor: 2 pliki (JSON, CSS)
  Kroje: 6 plików (WOFF2, TXT)
  Wzór: 1 plik (SVG)
  Ikony: 13 plików (SVG)
  Druk: 2 pliki (PDF)
  Media społecznościowe: 4 pliki (PNG)
  Podpis e-mail: 1 plik (HTML)
  Brand book: 1 plik (PDF)

Logo ma sześć wersji: główną, sygnet, poziomą, pionową, monochromatyczną czarną i negatyw.
Pliki SVG i PDF są wektorowe, pliki PNG mają przezroczyste tło.
Kroje są na licencji SIL OFL, jej tekst leży obok plików krojów.
CMYK w tabeli kolorów jest przybliżony. Do druku zamów próbny wydruk.
