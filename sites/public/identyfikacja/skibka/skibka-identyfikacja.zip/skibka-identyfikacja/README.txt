Skibka: identyfikacja wizualna

Projekt przykładowy. Skibka to zmyślona firma. Projekt i wykonanie: Adrian Turbiński.

Zawartość paczki:
  Logo: 30 plików (PDF, PNG, SVG)
  Ikona strony: 3 plików (PNG, ICO, SVG)
  Kolor: 2 plików (JSON, CSS)
  Kroje: 7 plików (WOFF2, TXT)
  Wzór: 1 plików (SVG)
  Ikony: 13 plików (SVG)
  Druk: 2 plików (PDF)
  Media społecznościowe: 4 plików (PNG)
  Podpis e-mail: 1 plików (HTML)
  Brand book: 1 plików (PDF)

Logo ma sześć wersji: główną, sygnet, poziomą, pionową, monochromatyczną czarną i negatyw.
Pliki SVG i PDF są wektorowe, pliki PNG mają przezroczyste tło.
Kroje są na licencji SIL OFL, jej tekst leży obok plików krojów.
CMYK w tabeli kolorów jest przybliżony. Do druku zamów próbny wydruk.
